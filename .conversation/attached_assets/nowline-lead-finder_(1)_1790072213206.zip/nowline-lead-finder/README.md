# Nowline Lead Finder

Apify (Google Maps) üzerinden, Nowline için en doğru potansiyel müşterileri
otomatik bulan ve puanlayan sistem. Sektör seçmene gerek yok — sistem geniş
bir sektör evrenini kendisi tarar (güzellik, klinik, emlak, oto, spor, eğitim,
restoran, mağaza, ajans vb.) ve "mesajlaşma otomasyonuna en çok ihtiyacı olan"
işletmeleri öne çıkarır.

## Replit'te Kurulum

1. Replit'te **Node.js** template ile yeni bir proje aç (veya "Import from
   GitHub / Upload folder" ile bu klasörün tamamını yükle).
2. Sol menüden **Secrets** (kilit 🔒 ikonu) sekmesine gir ve şunu ekle:
   - Key: `APIFY_API_TOKEN`
   - Value: Apify hesabındaki (yeni oluşturduğun) token
   > Önemli: Bu sohbette daha önce paylaştığın token'ı Apify panelinden iptal
   > edip yenisini oluştur — eski token artık güvenli sayılmaz.
3. Shell'de:
   ```
   npm install
   npm start
   ```
4. Replit sana bir "Webview" / public URL verecek — dashboard'a oradan
   ulaşırsın.

## Kullanım

1. Bölge alanına örn. `United Arab Emirates` veya `Dubai, United Arab
   Emirates` yaz.
2. "Taranacak sektör sayısı" — sistemin kendi listesinden kaç farklı iş
   koluna bakacağını belirler (varsayılan 12).
3. "En Doğru Müşterileri Bul" butonuna bas. Sistem Apify actor'ünü
   tetikleyecek, bulunan işletmelerin sitelerini tarayıp email/otomasyon izi
   arayacak ve hepsini tek bir listede puanlayıp sıralayacak.
4. Sonuçları CSV olarak indirebilirsin.

## Puanlama mantığı (server.js içindeki `scoreLead`)

- Website yoksa: +15 (mesajlaşma kanallarına daha bağımlı olabilir)
- Website var ama sitede chatbot/canlı destek izi yoksa: +10
- Sitede zaten chatbot/canlı destek/WhatsApp API izi varsa: −25 (zaten çözümü var)
- Email bulunduysa: +10 (kolay ulaşım)
- Dubai / Abu Dhabi gibi büyük iş merkezindeyse: +10
- Google yorum sayısı 15–600 arası (aktif ama dev olmayan işletme): +10
- Telefon numarası mevcutsa: +5

Bu kuralları `server.js` dosyasının en üstündeki `SECTOR_UNIVERSE` ve
`scoreLead` fonksiyonunu değiştirerek istediğin gibi ayarlayabilirsin.

## Maliyet notu

Her arama, seçilen sektör sayısı kadar Apify Google Maps çağrısı yapar
(varsayılan: 12 sektör × 8 sonuç ≈ 96 işletme). Apify kotanı kontrol etmek
için önce "sektör sayısı"nı düşük (örn. 5) tutarak test etmeni öneririm.
