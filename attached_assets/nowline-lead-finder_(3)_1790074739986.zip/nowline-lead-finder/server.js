require("dotenv").config();
const express = require("express");
const cors = require("cors");
const axios = require("axios");
const cheerio = require("cheerio");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

const APIFY_TOKEN = process.env.APIFY_API_TOKEN;
const GOOGLE_MAPS_ACTOR = "compass~crawler-google-places";
const INSTAGRAM_SEARCH_ACTOR = "apify~instagram-search-scraper";
const INSTAGRAM_PROFILE_ACTOR = "apify~instagram-profile-scraper";

// ---------------------------------------------------------------------------
// OTONOM SEKTOR EVRENI
// Kullanicidan sektor istenmiyor. Sistem, "musteriyle yogun mesajlasan,
// WhatsApp/Instagram/Telegram uzerinden satis yapan" tipteki isletme
// turlerini kendi icinde tarar. Bu liste NOWLINE'in genel profiline gore
// genis tutuldu; tek bir sektore kilitli degil.
// ---------------------------------------------------------------------------
const SECTOR_UNIVERSE = [
  "beauty salon", "hair salon", "nail salon", "spa",
  "dental clinic", "aesthetic clinic", "medical clinic", "physiotherapy clinic",
  "real estate agency", "property management company",
  "car dealership", "car rental company",
  "travel agency", "event planning company", "wedding hall",
  "photography studio", "fitness center", "gym", "yoga studio",
  "pet shop", "veterinary clinic",
  "furniture store", "interior design studio",
  "boutique clothing store", "jewelry store",
  "restaurant", "cafe", "catering company",
  "tutoring center", "language school", "driving school",
  "marketing agency", "IT services company",
];

const AUTOMATION_SIGNALS = [
  "whatsapp business api", "live chat", "livechat", "chatbot",
  "ai assistant", "intercom", "zendesk", "tawk.to", "crisp chat",
];

const HUB_CITIES = ["dubai", "abu dhabi"];

// ---------------------------------------------------------------------------
// Puanlama: sektore gore degil, "bu isletmenin mesajlasma otomasyonuna
// ihtiyaci var mi" sinyaline gore calisir. Hem Maps hem Instagram
// kaynaklarindan gelen lead'ler ayni normalize edilmis sekle sokulup
// (bkz normalizeMapsPlace / normalizeInstagramProfile) buradan gecer.
// ---------------------------------------------------------------------------
function scoreLead(lead, websiteInfo) {
  let score = 45; // baz puan (zaten hedef evrenden geldigi icin)
  const notes = [];

  if (!lead.website) {
    score += 15;
    notes.push("Website/dis link yok -> WhatsApp/Instagram gibi kanallara daha bagimli");
  } else if (websiteInfo) {
    if (websiteInfo.hasAutomationSignal) {
      score -= 25;
      notes.push("Sitede zaten bir chatbot/canli destek izi var");
    } else {
      score += 10;
      notes.push("Websitesi var ama otomasyon izi yok");
    }
    if (websiteInfo.email) {
      score += 10;
      notes.push("Email bulundu -> kolay ulasim");
    }
  }

  const city = (lead.city || lead.address || "").toLowerCase();
  if (HUB_CITIES.some((c) => city.includes(c))) {
    score += 10;
    notes.push("Buyuk is merkezi (Dubai/Abu Dhabi)");
  }

  if (lead.platform === "instagram") {
    const followers = lead.followersCount || 0;
    if (followers >= 500 && followers <= 50000) {
      score += 10;
      notes.push("Aktif ama mega hesap olmayan Instagram profili (ideal buyukluk)");
    } else if (followers > 50000) {
      score -= 5;
      notes.push("Cok buyuk/kurumsal Instagram hesabi olabilir");
    }
    if (lead.isBusinessAccount) {
      score += 5;
      notes.push("Instagram Business hesabi");
    }
  } else {
    const reviews = lead.reviewsCount || 0;
    if (reviews >= 15 && reviews <= 600) {
      score += 10;
      notes.push("Aktif ama kurumsal dev olmayan isletme (ideal buyukluk)");
    } else if (reviews > 600) {
      score -= 5;
      notes.push("Cok buyuk/kurumsal isletme olabilir");
    }
  }

  if (lead.phone) {
    score += 5;
    notes.push("Telefon numarasi mevcut");
  }

  score = Math.max(0, Math.min(100, score));
  return { score, notes };
}

async function extractEmailFromWebsite(url) {
  try {
    const target = url.startsWith("http") ? url : `https://${url}`;
    const parsed = new URL(target);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      return { email: null, hasAutomationSignal: false };
    }
    const res = await axios.get(target, {
      timeout: 8000,
      maxContentLength: 3 * 1024 * 1024, // 3MB ile sinirla
      headers: { "User-Agent": "Mozilla/5.0 (compatible; NowlineLeadBot/1.0)" },
      maxRedirects: 3,
    });
    const html = res.data;
    const $ = cheerio.load(html);
    const text = $.root().text();

    const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
    const found = (text.match(emailRegex) || []).filter(
      (e) => !/\.(png|jpg|jpeg|gif|svg|webp)$/i.test(e)
    );

    const lowerHtml = html.toLowerCase();
    const hasAutomationSignal = AUTOMATION_SIGNALS.some((s) => lowerHtml.includes(s));

    return { email: found.length ? found[0] : null, hasAutomationSignal };
  } catch (err) {
    return { email: null, hasAutomationSignal: false };
  }
}

function extractEmailFromText(text) {
  if (!text) return null;
  const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  const found = text.match(emailRegex);
  return found && found.length ? found[0] : null;
}

// ---------------------------------------------------------------------------
// Maps ve Instagram'dan gelen farkli sekilli objeleri ayni "lead" formatina
// ceviren normalize fonksiyonlari.
// ---------------------------------------------------------------------------
function normalizeMapsPlace(p) {
  return {
    platform: "maps",
    name: p.title || "Bilinmiyor",
    website: p.website || null,
    phone: p.phone || null,
    category: p.categoryName || null,
    address: p.address || null,
    city: p.city || null,
    rating: p.totalScore || null,
    reviewsCount: p.reviewsCount || null,
    profileUrl: p.url || null,
  };
}

function normalizeInstagramProfile(p) {
  const bioEmail = extractEmailFromText(p.biography || p.bio || "");
  return {
    platform: "instagram",
    name: p.fullName || p.username || "Bilinmiyor",
    website: p.externalUrl || p.website || null,
    phone: null,
    category: "Instagram profili",
    address: null,
    city: null,
    followersCount: p.followersCount || 0,
    isBusinessAccount: !!p.isBusinessAccount,
    bioEmail,
    profileUrl: p.username ? `https://instagram.com/${p.username}` : null,
  };
}

async function runApifySearch(searchStrings, location, maxPerQuery) {
  const apifyRes = await axios.post(
    `https://api.apify.com/v2/acts/${GOOGLE_MAPS_ACTOR}/run-sync-get-dataset-items`,
    {
      searchStringsArray: searchStrings,
      maxCrawledPlacesPerSearch: maxPerQuery,
      language: "en",
      locationQuery: location,
      skipClosedPlaces: true,
    },
    { params: { token: APIFY_TOKEN }, timeout: 1000 * 60 * 8 }
  );
  return (apifyRes.data || []).map(normalizeMapsPlace);
}

// Instagram: once anahtar kelime + sehir ile hesap arar, sonra bulunan
// kullanici adlarinin tam profilini (bio, dis link, takipci sayisi) ceker.
async function runInstagramSearch(searchTerms, location, maxPerTerm) {
  const searchRes = await axios.post(
    `https://api.apify.com/v2/acts/${INSTAGRAM_SEARCH_ACTOR}/run-sync-get-dataset-items`,
    {
      search: searchTerms.map((t) => `${t} ${location}`),
      searchType: "user",
      searchLimit: maxPerTerm,
    },
    { params: { token: APIFY_TOKEN }, timeout: 1000 * 60 * 8 }
  );

  const usernames = [
    ...new Set(
      (searchRes.data || [])
        .map((u) => u.username)
        .filter(Boolean)
    ),
  ];

  if (!usernames.length) return [];

  const profileRes = await axios.post(
    `https://api.apify.com/v2/acts/${INSTAGRAM_PROFILE_ACTOR}/run-sync-get-dataset-items`,
    { usernames },
    { params: { token: APIFY_TOKEN }, timeout: 1000 * 60 * 8 }
  );

  return (profileRes.data || []).map(normalizeInstagramProfile);
}

// ---------------------------------------------------------------------------
// POST /api/discover
// body: { location, sectorCount, maxPerSector, topN, source: "maps" | "instagram" | "both" }
// Kullanicidan sektor ISTEMEZ. SECTOR_UNIVERSE icinden otomatik secim yapar,
// secilen kaynag(lar)i tarar, tek bir havuzda puanlayip en iyileri dondurur.
// ---------------------------------------------------------------------------
app.post("/api/discover", async (req, res) => {
  try {
    if (!APIFY_TOKEN) {
      return res.status(500).json({ error: "APIFY_API_TOKEN tanimli degil. Replit Secrets kismina ekle." });
    }

    const {
      location = "United Arab Emirates",
      sectorCount = 12,
      maxPerSector = 8,
      topN = 50,
      source = "maps", // "maps" | "instagram" | "both"
    } = req.body || {};

    if (!["maps", "instagram", "both"].includes(source)) {
      return res.status(400).json({ error: "source degeri 'maps', 'instagram' veya 'both' olmali." });
    }

    const shuffled = [...SECTOR_UNIVERSE].sort(() => Math.random() - 0.5);
    const chosenSectors = shuffled.slice(0, Math.min(sectorCount, SECTOR_UNIVERSE.length));
    const searchStrings = chosenSectors.map((s) => `${s} in ${location}`);

    let rawLeads = [];
    if (source === "maps" || source === "both") {
      const mapsLeads = await runApifySearch(searchStrings, location, maxPerSector);
      rawLeads.push(...mapsLeads);
    }
    if (source === "instagram" || source === "both") {
      const igLeads = await runInstagramSearch(chosenSectors, location, maxPerSector);
      rawLeads.push(...igLeads);
    }

    const enriched = [];
    const BATCH = 5;
    for (let i = 0; i < rawLeads.length; i += BATCH) {
      const batch = rawLeads.slice(i, i + BATCH);
      const results = await Promise.all(
        batch.map(async (lead) => {
          const websiteInfo = lead.website ? await extractEmailFromWebsite(lead.website) : null;
          // Instagram profilinde bio'dan bulunan email'i de dikkate al
          const email = websiteInfo?.email || lead.bioEmail || null;
          const { score, notes } = scoreLead(lead, websiteInfo);
          return {
            platform: lead.platform,
            name: lead.name,
            website: lead.website,
            email,
            phone: lead.phone,
            category: lead.category,
            address: lead.address,
            rating: lead.rating || null,
            reviewsCount: lead.reviewsCount || null,
            followersCount: lead.followersCount || null,
            profileUrl: lead.profileUrl || null,
            score,
            notes,
          };
        })
      );
      enriched.push(...results);
    }

    // Ayni isletme/hesap farkli aramalardan iki kere gelmis olabilir -> tekillestir
    const seen = new Set();
    const deduped = enriched.filter((l) => {
      const key = `${l.platform}|${l.name}|${l.address || l.profileUrl}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    deduped.sort((a, b) => b.score - a.score);
    const top = deduped.slice(0, topN);

    res.json({
      source,
      scannedSectors: chosenSectors,
      totalFound: deduped.length,
      returned: top.length,
      leads: top,
    });
  } catch (err) {
    console.error(err?.response?.data || err.message);
    res.status(500).json({ error: "Arama sirasinda hata olustu.", detail: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Nowline Lead Finder http://localhost:${PORT} adresinde calisiyor`));
